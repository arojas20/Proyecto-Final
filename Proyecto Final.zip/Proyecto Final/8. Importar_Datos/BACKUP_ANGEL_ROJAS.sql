-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: quesera
-- ------------------------------------------------------
-- Server version	8.0.29


/* Se crea Respaldo de las tablas que componen la base de datos, incluyendo las tablas de auditorias, el listado de las tablas es :
* ALMACEN
* CLIENTE
* DETALLE_PRODUCCION
* LOG_AUDITORIA_PC
* LOG_CLIENTE
* LOG_MODALMACEN
* MATERIA_PRIMA
* PRODUCCION
* PRODUCTO_CLIENTES
* PRODUCTO_TERMINADO
* PROVEEDOR
* TIPO_ALMACEN
* TIPO_MATERIA_PRIMA
* TIPO_PRODUCTO
    */

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `almacen`
--

LOCK TABLES `almacen` WRITE;
/*!40000 ALTER TABLE `almacen` DISABLE KEYS */;
INSERT INTO `almacen` VALUES (1,'Materia Prima 01','500',10000,3,1),(2,'Materia Prima 02','500',10000,5,1),(3,'Materia Prima 03','500',10000,5,1),(4,'Materia Prima 04','500',10000,15,1),(5,'Materia Prima 05','500',10000,10,1),(6,'Terminado 01','500',10000,5,2),(7,'Terminado 02','500',10000,5,2),(8,'Terminado 03','500',10000,5,2),(9,'Terminado 04','500',10000,5,2),(10,'Terminado 05','500',10000,5,2),(11,'Deposito 01','500',10000,3,3),(12,'Deposito 02','500',10000,3,3),(13,'Deposito 03','500',10000,5,3),(14,'Deposito 04','500',10000,5,3),(15,'Deposito 05','500',10000,5,3);
/*!40000 ALTER TABLE `almacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,11111111,'Antonio','Trejo','Calle 01 casa 23','2215458821','atrejo@correo.com',1900),(2,22222222,'Luis','Prado','Calle 15 casa 20','2215625530','lprado@correo.com',1900),(3,33333333,'Juan','Pareto','Calle 10 casa 32','1115458825','jpareto@correo.com',1901),(4,44444444,'Carlos','Rojas','Calle 21 casa 23','2215465236','crojas@correo.com',1900),(5,55555555,'Jose','Cabrera','Calle 15 casa 12','1153625550','jcabrera@correo.com',1900),(6,66666666,'Miguel','Tineo','Calle 20 casa 13','2213685228','mtineo@correo.com',1903),(7,77777777,'Felipe','Flores','Calle 12 casa 60','2215420145','ffores@correo.com',1902),(8,88888888,'German','Garcias','Calle 08 casa 01','2216352428','ggarcias@correo.com',1902),(9,99999999,'Maria','Rivera','Calle 15 casa 45','2320255588','mrivera@correo.com',1900),(10,11111112,'Carmen','Gutierrez','Calle 10 casa 15','2215663332','cgutierrez@correo.com',1900),(11,22222223,'Luisa','Diaz','Calle 19 casa 53','1125687852','ldiaz@correo.com',1900),(12,33333334,'Fermin','Rodriguez','Calle 25 casa 22','2215685542','frodriguez@correo.com',1903),(13,44444445,'Nicolas','Martinez','Calle 20 casa 40','2215698855','nmartinez@correo.com',1900),(14,55555556,'Karla','Rojas','Calle 30 casa 25','2214778569','krojas@correo.com',1903),(15,14670561,'Maria','Tirado','Calle 11 casa 32','1125586230','mtirado@correo.com',1900),(16,77777778,'Miguel','Cabrera','Calle 08 casa 52','2212569843','mcabrera@correo.com',1900),(17,88888889,'Jose','Lezama','Calle 05 casa 23','2325556525','jlezama@correo.com',1900),(18,99999990,'Feipe','Aguilera','Calle 01 casa 05','2212323236','faguilera@correo.com',1900),(19,11111123,'Angel','Torres','Calle 23 casa 51','1125693665','atorres@correo.com',1900),(20,22222234,'Alberto','Farias','Calle 11 casa 13','2215458800','afarias@correo.com',1900),(21,33333345,'Mario','Ramirez','Calle 01 casa 02','2215400255','mramirez@correo.com',1905),(22,44444456,'Fernando','Lopez','Calle 18 casa 09','2215802150','flopez@correo.com',1902),(23,55555567,'Francisco','Millan','Calle 05 casa 33','2215468985','fmillan@correo.com',1901),(24,66666678,'Juan','Figueroa','Calle 19 casa 20','2216359696','jfigueroa@correo.com',1900),(25,77777789,'Julian','Lemus','Calle 03 casa 23','2217532636','jlemus@correo.com',1900),(26,88888890,'Pedro','Lezama','Calle 05 casa 57','2216356363','plezama@correo.com',1900),(27,99999991,'Federico','Rodriguez','Calle 15 casa 12','2215821218','frodriguez@correo.com',1900),(28,11111234,'Carlos','Ribas','Calle 21 casa 53','2216265855','cribas@correo.com',1903),(29,22222345,'Mariana','Diaz','Calle 31 casa 33','1125458800','mdiaz@correo.com',1903),(30,33333456,'Flor','Nunez','Calle 08 casa 26','2215455602','fnunez@corrreo.com',1900);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `detalle_produccion`
--

LOCK TABLES `detalle_produccion` WRITE;
/*!40000 ALTER TABLE `detalle_produccion` DISABLE KEYS */;
INSERT INTO `detalle_produccion` VALUES (1,1,1,100,1),(2,2,1,1,1),(3,4,1,1,1),(4,1,2,100,2),(5,2,2,1,2),(6,4,2,1,2),(7,1,3,100,2),(8,2,3,1,2),(9,4,3,1,2),(10,1,4,100,2),(11,2,4,1,2),(12,4,4,1,2),(13,1,5,100,1),(14,2,5,1,1),(15,4,5,1,1),(16,1,6,100,2),(17,2,6,1,2),(18,4,6,1,2),(19,1,7,100,2),(20,2,7,1,2),(21,4,7,1,2),(22,1,8,100,2),(23,2,8,1,2),(24,4,8,1,2),(25,1,9,100,1),(26,2,9,1,1),(27,4,9,1,1),(28,1,10,100,2),(29,2,10,1,2),(30,4,10,1,2),(31,1,11,100,2),(32,2,11,1,2),(33,4,11,1,2),(34,1,12,100,2),(35,2,12,1,2),(36,4,12,1,2),(37,1,13,100,1),(38,2,13,1,1),(39,4,13,1,1),(40,1,14,100,2),(41,2,14,1,2),(42,4,14,1,2),(43,1,15,100,2),(44,2,15,1,2),(45,4,15,1,2),(46,1,16,100,2),(47,2,16,1,2),(48,4,16,1,2);
/*!40000 ALTER TABLE `detalle_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `log_auditoria_pc`
--

LOCK TABLES `log_auditoria_pc` WRITE;
/*!40000 ALTER TABLE `log_auditoria_pc` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_auditoria_pc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `log_cliente`
--

LOCK TABLES `log_cliente` WRITE;
/*!40000 ALTER TABLE `log_cliente` DISABLE KEYS */;
INSERT INTO `log_cliente` VALUES (1,14670561,'UPDATE','CLIENTE','root@localhost','2022-08-04','13:57:03');
/*!40000 ALTER TABLE `log_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `log_modalmacen`
--

LOCK TABLES `log_modalmacen` WRITE;
/*!40000 ALTER TABLE `log_modalmacen` DISABLE KEYS */;
INSERT INTO `log_modalmacen` VALUES (1,15,'ALMACEN','DELETE','root@localhost','2022-08-04','15:11:43');
/*!40000 ALTER TABLE `log_modalmacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `materia_prima`
--

LOCK TABLES `materia_prima` WRITE;
/*!40000 ALTER TABLE `materia_prima` DISABLE KEYS */;
INSERT INTO `materia_prima` VALUES (1,'Leche','Leche Liquida',1,1,400,'400010622',1),(2,'Suero','Suero para Queso',1,2,3,'3200522',2),(3,'Bolsas Pequeñas','Bolsas para Guardar Quesos',4,6,500,'BG100001',3),(4,'Bolsas Grandes','Bolsas para Guardar Quesos',4,6,500,'BP100001',3),(5,'Sal','Sal Para Quesos',1,4,50,'SAL500622',4),(6,'Azucar','Azucar',1,4,10,'AZU100622',4),(7,'Bolsas de Empaque','Bolsas de Empaque al Vacio',4,7,1000,'BE100001',5),(8,'Moldes01','Molde para Queso Duro',4,5,10,'MOL10001',6),(9,'Moldes02','Molde para Queso Semi Duro',4,5,10,'MOL20001',6),(10,'Moldes03','Molde para Queso Madurado',4,5,10,'MOL30001',6),(11,'Moldes04','Molde para Queso Parmesano',4,5,10,'MOL40001',6),(12,'Moldes05','Molde para Queso de Año',4,5,10,'MOL50001',6),(13,'Moldes06','Molde para Queso Mozzarella',4,5,10,'MOL60001',6),(14,'Moldes07','Molde para Manteca',4,5,10,'MOL70001',6),(15,'Etriquetas01','Etiquetas para identificar Queso Duro',4,8,1000,'ET1000001',7),(16,'Etriquetas02','Etiquetas para identificar Queso Semi Duro',4,8,1000,'ET2000001',7),(17,'Etriquetas03','Etiquetas para identificar Queso Madurado',4,8,1000,'ET3000001',7),(18,'Etriquetas04','Etiquetas para identificar Queso Parmesano',4,8,1000,'ET4000001',7),(19,'Etriquetas05','Etiquetas para identificar Queso de Año',4,8,1000,'ET5000001',7),(20,'Etriquetas06','Etiquetas para identificar Queso Mozzarella',4,8,1000,'ET6000001',7),(21,'Etriquetas07','Etiquetas para identificar Manteca',4,8,1000,'ET7000001',7);
/*!40000 ALTER TABLE `materia_prima` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `produccion`
--

LOCK TABLES `produccion` WRITE;
/*!40000 ALTER TABLE `produccion` DISABLE KEYS */;
INSERT INTO `produccion` VALUES (1,1,'2001-06-22','2030-06-22',15,'QD1501062201'),(2,2,'2001-06-22','2030-06-22',15,'QS1501062201'),(3,2,'2001-06-22','2030-06-22',15,'QS1501062202'),(4,2,'2001-06-22','2030-06-22',15,'QS1501062203'),(5,1,'2002-06-22','2001-07-22',15,'QD1502062201'),(6,2,'2002-06-22','2001-07-22',15,'QS1502062201'),(7,2,'2002-06-22','2001-07-22',15,'QS1502062202'),(8,2,'2002-06-22','2001-07-22',15,'QS1502062203'),(9,1,'2003-06-22','2002-07-22',15,'QD1503062201'),(10,2,'2003-06-22','2002-07-22',15,'QS1503062201'),(11,2,'2003-06-22','2002-07-22',15,'QS1503062202'),(12,2,'2003-06-22','2002-07-22',15,'QS1503062203'),(13,1,'2004-06-22','2003-07-22',15,'QD1504062201'),(14,2,'2004-06-22','2003-07-22',15,'QS1504062201'),(15,2,'2004-06-22','2003-07-22',15,'QS1504062202'),(16,2,'2004-06-22','2003-07-22',15,'QS1504062203');
/*!40000 ALTER TABLE `produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `producto_clientes`
--

LOCK TABLES `producto_clientes` WRITE;
/*!40000 ALTER TABLE `producto_clientes` DISABLE KEYS */;
INSERT INTO `producto_clientes` VALUES (1,1,1,1),(2,2,2,2),(3,3,1,1),(4,4,2,2),(5,5,1,1),(6,6,2,2),(7,7,1,3),(8,8,2,4),(9,9,1,5),(10,10,2,4),(11,11,1,21),(12,12,2,1),(13,13,1,1),(14,14,2,1),(15,15,1,1),(16,16,1,5),(17,17,1,6),(18,18,1,5),(19,19,1,2),(20,20,1,4),(21,21,1,2),(22,22,2,5),(23,23,2,1),(24,24,2,3),(25,25,2,1),(26,26,1,1),(27,27,2,4),(28,1,1,1),(29,2,1,1),(30,3,1,2),(31,4,2,1),(32,1,2,1),(33,2,2,1),(34,1,1,2),(35,10,2,2),(36,10,2,3),(37,8,2,1),(38,10,1,1);
/*!40000 ALTER TABLE `producto_clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `producto_terminado`
--

LOCK TABLES `producto_terminado` WRITE;
/*!40000 ALTER TABLE `producto_terminado` DISABLE KEYS */;
INSERT INTO `producto_terminado` VALUES (1,'Quedo Duro',100,30,200,950,1,6),(2,'Queso Semi Duro',200,30,300,950,2,7),(3,'Queso Madurado',50,15,70,1000,3,8),(4,'Manteca',70,10,100,200,7,11),(5,'Quedo de Año',10,5,40,1000,4,12),(6,'Queso Parmesano',25,10,50,2500,5,13),(7,'Queso Mozzarella',25,10,50,500,6,14),(8,'Nata',20,5,35,500,8,11),(9,'Queso Crema',20,5,35,900,9,11),(10,'Yogourt',20,5,35,200,10,11);
/*!40000 ALTER TABLE `producto_terminado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (1,'30002550361','Provee_01','Calle 01 casa 23','2215452121','Provee_01@correo.com',1901,'Alberto Luna'),(2,'30002565061','Provee_02','Calle 15 casa 20','2215625530','Provee_02@correo.com',1902,'Federico Rojas'),(3,'30002550325','Provee_03','Calle 10 casa 32','1115458825','Provee_03@correo.com',1901,'Luis Prado'),(4,'30002550361','Provee_04','Calle 21 casa 23','2215465236','Provee_04@correo.com',1900,'Carlos Lopez'),(5,'30052050361','Provee_05','Calle 15 casa 12','1153625550','Provee_05@correo.com',1900,'Angel Ribas'),(6,'30002555633','Provee_06','Calle 20 casa 13','2213685228','Provee_06@correo.com',1900,'Rolando Luna'),(7,'30002563589','Provee_07','Calle 12 casa 60','2215420145','Provee_07@correo.com',1903,'Carlos Perez'),(8,'30036589648','Provee_08','Calle 08 casa 01','2216352428','Provee_08@correo.com',1903,'Nino Ruiz'),(9,'30002598989','Provee_09','Calle 15 casa 45','2320255588','Provee_09@correo.com',1903,'Miguel Cuevas'),(10,'30252525355','Provee_10','Calle 10 casa 15','2215663332','Provee_10@correo.com',1900,'Leandro Nieves'),(11,'30002578787','Provee_11','Calle 19 casa 53','1125687852','Provee_11@correo.com',1900,'Pedro Perez'),(12,'30065895223','Provee_12','Calle 25 casa 22','2215685542','Provee_12@correo.com',1900,'Angel Perez'),(13,'30063698582','Provee_13','Calle 20 casa 40','2215698855','Provee_13@correo.com',1900,'Luis Sanchez'),(14,'30063589563','Provee_14','Calle 30 casa 25','2214778569','Provee_14@correo.com',1900,'Antonio Ruiz'),(15,'30236599563','Provee_15','Calle 11 casa 32','1125586230','Provee_15@correo.com',1900,'Maria Lara'),(16,'30002369580','Provee_16','Calle 08 casa 52','2212569843','Provee_16@correo.com',1903,'Fabian Moreno'),(17,'33265915200','Provee_17','Calle 05 casa 23','2325556525','Provee_17@correo.com',1903,'Maria Cabrera'),(18,'30098646239','Provee_18','Calle 01 casa 05','2212323236','Provee_18@correo.com',1903,'Mariana Ortiz'),(19,'30002536996','Provee_19','Calle 23 casa 51','1125693665','Provee_19@correo.com',1903,'Jose Lara'),(20,'30036528956','Provee_20','Calle 11 casa 13','2215458800','Provee_20@correo.com',1903,'Miguel Lopez'),(21,'30002515698','Provee_21','Calle 01 casa 02','2215400255','Provee_21@correo.com',1903,'Maria Farias'),(22,'30032659863','Provee_22','Calle 18 casa 09','2215802150','Provee_22@correo.com',1902,'Luisa Veliz'),(23,'30002552589','Provee_23','Calle 05 casa 33','2215468985','Provee_23@correo.com',1902,'Vanesa Lira'),(24,'30363962565','Provee_24','Calle 19 casa 20','2216359696','Provee_24@correo.com',1901,'Pedro Lunar'),(25,'30063698563','Provee_25','Calle 03 casa 23','2217532636','Provee_25@correo.com',1903,'Fabricio Perez'),(26,'30003232656','Provee_26','Calle 05 casa 57','2216356363','Provee_26@correo.com',1901,'Alberto Rojas'),(27,'30002365745','Provee_27','Calle 15 casa 12','2215821218','Provee_27@correo.com',1901,'Juan Diaz'),(28,'30545454855','Provee_28','Calle 21 casa 53','2216265855','Provee_28@correo.com',1900,'Gabriel Ribas'),(29,'30365200011','Provee_29','Calle 31 casa 33','1125458800','Provee_29@correo.com',1902,'Pedro Perez'),(30,'30002523565','Provee_30','Calle 08 casa 26','2215455602','Provee_30@correo.com',1903,'Luis Lopez');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_almacen`
--

LOCK TABLES `tipo_almacen` WRITE;
/*!40000 ALTER TABLE `tipo_almacen` DISABLE KEYS */;
INSERT INTO `tipo_almacen` VALUES (1,'Materia Prima','Materia Prima para Produccion'),(2,'Producto Terminado','Producto Terminado despues de Produccion'),(3,'Deposito','Deposito de Productos Terminados'),(4,'Material de Empaque','Material de empaque para productos terminados');
/*!40000 ALTER TABLE `tipo_almacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_materia_prima`
--

LOCK TABLES `tipo_materia_prima` WRITE;
/*!40000 ALTER TABLE `tipo_materia_prima` DISABLE KEYS */;
INSERT INTO `tipo_materia_prima` VALUES (1,'Lacteo','Leche','Provee_01',400,'400010622'),(2,'Suero Normal','Suero Normal para cuajar','Provee_02',1,'3200522'),(3,'Suero Agrio','Suero Agrio para Cuajar','Provee_02',1,'3200522'),(4,'Aditivo','Condimento (Sal, Azucar, ETC)','Provee_03',1,'SAL500622'),(5,'Moldes','Moldes para los  productos','Provee_06',500,'MOL10001'),(6,'Envases','Envases para los Productos','Provee_04',500,'BG100001'),(7,'Empaque','Empaques para los productos','Provee_05',500,'BE100001'),(8,'Etiquetado','Etiquetas de Productos','Provee_07',1000,'ET1000001');
/*!40000 ALTER TABLE `tipo_materia_prima` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tipo_producto`
--

LOCK TABLES `tipo_producto` WRITE;
/*!40000 ALTER TABLE `tipo_producto` DISABLE KEYS */;
INSERT INTO `tipo_producto` VALUES (1,'Queso_01','Quedo Duro',15),(2,'Queso_02','Queso Semi Duro',15),(3,'Queso_03','Queso Madurado',15),(4,'Queso_04','Quedo de Año',15),(5,'Queso_05','Queso Parmesano',5),(6,'Queso_06','Queso Mozzarella',5),(7,'Manteca','Manteca',3),(8,'Nata','Nata',3),(9,'Queso_Crema','Queso Crema',3),(10,'Yogourt','Yogourt',3);
/*!40000 ALTER TABLE `tipo_producto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-16 11:03:44
